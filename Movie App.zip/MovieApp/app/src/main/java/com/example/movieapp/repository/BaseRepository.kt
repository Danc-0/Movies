package com.example.movieapp.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.HttpException

abstract class BaseRepository {

    suspend fun <T> safeApiCall(
        apiCall: suspend () -> T
    ) {
        return withContext(Dispatchers.IO) {
            try {
                apiCall.invoke()
            } catch (throwable: Throwable) {
                when (throwable) {
                    is HttpException -> {
                    }

                    else -> {

                    }
                }
            }
        }
    }
}