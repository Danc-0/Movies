package com.example.movieapp.model

data class Movie (

    val id: Int,
    val poster_path: String,
    val vote_average: Double
)